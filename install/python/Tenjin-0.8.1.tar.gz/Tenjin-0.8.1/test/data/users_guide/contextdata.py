items = [ '<FOO>', '&BAR', '"BAZ"' ]
webmaster_email = 'webmaster@example.com'
menu  = [
    {'name': 'Top',      'url': '/' },
    {'name': 'Products', 'url': '/prod' },
    {'name': 'Support',  'url': '/support' },
]
