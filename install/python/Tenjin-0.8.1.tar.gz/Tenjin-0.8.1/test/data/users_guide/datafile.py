text  = "foo"
num   = 3.14
flag  = True
items = ["foo", "bar", "baz"]
hash  = {"x":1, "y":2}
